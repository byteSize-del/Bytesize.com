document.addEventListener('DOMContentLoaded', () => {
    // --- Interactive Grid Background ---
    const gridContainer = document.getElementById('grid-container');
    const cellSize = 50;

    function createGrid() {
        gridContainer.innerHTML = '';
        const columns = Math.floor(window.innerWidth / cellSize);
        const rows = Math.floor(window.innerHeight / cellSize);
        gridContainer.style.setProperty('--columns', columns);
        const totalCells = columns * rows;
        for (let i = 0; i < totalCells; i++) {
            const cell = document.createElement('div');
            cell.classList.add('grid-cell');
            cell.addEventListener('mouseover', () => {
                cell.classList.add('lit');
                setTimeout(() => {
                    cell.classList.remove('lit');
                }, 800);
            });
            gridContainer.appendChild(cell);
        }
    }
    createGrid();
    window.addEventListener('resize', createGrid);

    // --- Initial Title Typewriter Effect ---
    const titleElement = document.getElementById('title');
    if (titleElement) {
        const originalText = "> ACCESSING SYSTEM...";
        const initialTypingSpeed = 100;
        let i = 0;
        titleElement.textContent = "> ";
        titleElement.setAttribute('data-text', '> ');

        function typeWriter() {
            if (i < originalText.length) {
                titleElement.textContent += originalText.charAt(i);
                titleElement.setAttribute('data-text', titleElement.textContent);
                i++;
                setTimeout(typeWriter, initialTypingSpeed);
            } else {
                titleElement.innerHTML += '<span class="cursor">_</span>';
            }
        }
        typeWriter();
    }

    // --- Login Success Animation ---
    const loginForm = document.querySelector('.login-form');
    const loginContainer = document.querySelector('.login-container');

    if (loginForm && loginContainer) {
        loginForm.addEventListener('submit', (e) => {
            // CRITICAL: This line stops the page from reloading.
            e.preventDefault();

            // Add class to start the fade-out animation
            loginContainer.classList.add('success');

            // Wait for the fade-out to finish, then change the content
            setTimeout(() => {
                loginContainer.innerHTML = ''; // Clear the form
                const successMessage = document.createElement('h1');
                successMessage.className = 'glitch success-message';
                loginContainer.appendChild(successMessage);

                const successText = "SYSTEM ACCESS GAINED... IMPORTING DATA...";
                const successTypingSpeed = 80;
                let j = 0;

                function typeSuccessMessage() {
                    if (j < successText.length) {
                        successMessage.textContent += successText.charAt(j);
                        successMessage.setAttribute('data-text', successMessage.textContent);
                        j++;
                        setTimeout(typeSuccessMessage, successTypingSpeed);
                    } else {
                        successMessage.innerHTML += '<span class="cursor">_</span>';
                    }
                }
                typeSuccessMessage();
            }, 600); // This delay must be slightly longer than the CSS transition
        });
    }
});